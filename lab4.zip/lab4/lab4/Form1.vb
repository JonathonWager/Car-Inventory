﻿'Jonathon Wager 100698641
'NETD2202
'Lab 4 Car Inventory
Option Strict On
Public Class Form1
    'declaring a list that the car objects will be stored
    Public ListofCars As New SortedList
    'When the user is entering cars to the display box
    Private EditOn As Boolean = False
    'this is for when displaying the table ie the current car
    Private selectedCarIdentificationNumber As String = ""


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnAccept.Click
        'Making a new car object

        Dim Newcar As New car
        'Runing a validate function to check if user has entered valid inputs
        If ValidateInput() Then
            'turn editing on because the user is editing cars now
            EditOn = True
            If (selectedCarIdentificationNumber.Trim.Length = 0) Then
                'Creating a new car with users inputs that have been validated
                Newcar = New car(cmbMake.Text, txtModel.Text.Trim, Convert.ToInt32(cmbYear.Text), Convert.ToDecimal(txtPrice.Text.Trim), chkNewCar.Checked)
                'adding it to the list of cars
                ListofCars.Add(Newcar.GetIdentificationNumber(), Newcar)
            Else

            End If
            cbxCars.Items.Clear()
            'printing the cars to the table that are on the list
            'using a for eachloop that loops threw the list
            For Each carEntry As DictionaryEntry In ListofCars
                'Creating a new veiw list item
                Dim CarPropertys As New ListViewItem

                Newcar = CType(carEntry.Value, car)
                'adding propertys to table
                CarPropertys.Checked = Newcar.GetNewStatus()
                CarPropertys.SubItems.Add(Newcar.GetIdentificationNumber.ToString())
                CarPropertys.SubItems.Add(Newcar.GetMake())
                CarPropertys.SubItems.Add(Newcar.GetModel)
                CarPropertys.SubItems.Add(Newcar.GetYear)
                CarPropertys.SubItems.Add(Newcar.GetPrice().ToString("c"))
                cbxCars.Items.Add(CarPropertys)
            Next

            ResetInputBoxes()

        End If




    End Sub
    'if they hit reset
    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        ResetInputBoxes()

    End Sub
    'validation function that checks user input
    Private Function ValidateInput() As Boolean
        'creating a test price varible
        Dim TestPrice As Decimal
        'and a validation test boolean
        Dim ValidationTest As Boolean = True
        'ifthey didnt slect one of the drop down makes
        If cmbMake.SelectedIndex = -1 Then
            lblErrors.Text = lblErrors.Text + "Please Select one of the Provided Car Makes" + Environment.NewLine()
            ValidationTest = False

        End If
        'if they didnt enter valid price
        If Not Decimal.TryParse(txtPrice.Text.Trim, TestPrice) Then
            ValidationTest = False
            lblErrors.Text = lblErrors.Text + "Please Enter a valid price amount" + Environment.NewLine()
        End If
        'if they didnt enter any model 
        If txtModel.Text = "" Then
            ValidationTest = False
            lblErrors.Text = lblErrors.Text + "Please Enter a Car Model" + Environment.NewLine()
        End If
        'if they didnt slect a year
        If cmbYear.SelectedIndex = -1 Then
            ValidationTest = False
            lblErrors.Text = lblErrors.Text + "Please Select one of the Provided Years the car was made" + Environment.NewLine()
        End If
        Return ValidationTest
    End Function
    'resets input boxes
    Private Sub ResetInputBoxes()
        cmbMake.SelectedIndex = -1
        txtModel.Text = ""
        cmbYear.SelectedIndex = -1
        txtPrice.Text = ""
        chkNewCar.Checked = False
        lblErrors.Text = ""
        cmbMake.Select()
        EditOn = False


        For Each carItem As ListViewItem In Me.cbxCars.Items
            carItem.BackColor = Color.White
        Next

        selectedCarIdentificationNumber = ""
    End Sub

    'exits form
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()

    End Sub
End Class


