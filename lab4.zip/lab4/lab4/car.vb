﻿'Jonathon Wager 100698641
'NETD2202
'Lab 4 Car Inventory

'turning option stricted on
Option Strict On
Public Class car

#Region "Properties"
    'Storage varivles for the car objects ie make model year and price
    Private Shared Count As Integer = 0
    Private IdentificationNumber As Integer

    Private Make As String
    Private Model As String

    Private Year As Integer
    Private Price As Decimal

    Private NewStatus As Boolean
#End Region

#Region "Constructors"
    'Default Constructor
    Public Sub New()
        Count = Count + 1
        IdentificationNumber = Count
    End Sub
    'Constructor by Value, Makes Custom Cars for the table 
    Public Sub New(ByVal assignedMake As String, ByVal assignedModel As String, ByVal assignedYear As Integer, ByVal assignedPrice As Decimal, ByVal assignedNewStatus As Boolean)

        Make = assignedMake
        Model = assignedModel
        Year = assignedYear
        Price = assignedPrice
        NewStatus = assignedNewStatus
    End Sub

#End Region

#Region "Property Procedures"
    'Gets value returned from class because the varibles are private and protected
    Public Property GetYear() As String
        Get
            Return Convert.ToString(Year)
        End Get
        Set(value As String)
            Year = Convert.ToInt32(value)
        End Set
    End Property

    'Gets identification Number from class
    Public ReadOnly Property GetIdentificationNumber() As Integer
        Get
            Return IdentificationNumber
        End Get
    End Property

    'Gets make of car from class
    Public Property GetMake() As String
        Get
            Return Make
        End Get
        Set(value As String)
            Make = value
        End Set
    End Property

    'Gets the amount of cars stored so far
    Public ReadOnly Property carCount() As Integer
        Get
            Return Count
        End Get
    End Property
    'returns if car is new
    Public Property GetNewStatus() As Boolean
        Get
            Return NewStatus
        End Get
        Set(value As Boolean)
            NewStatus = value
        End Set
    End Property
    'returns price from class
    Public Property GetPrice() As Double
        Get
            Return Price
        End Get
        Set(value As Double)
            Price = Convert.ToDecimal(Math.Round(value, 2))
        End Set
    End Property
    'Returns model from from the class
    Public Property GetModel() As String
        Get
            Return Model
        End Get
        Set(value As String)
            Model = value
        End Set
    End Property
    Public Sub resetCarCount()
        IdentificationNumber = 0
        Count = 0
    End Sub
#End Region



End Class
