﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.cmbMake = New System.Windows.Forms.ComboBox()
        Me.cmbYear = New System.Windows.Forms.ComboBox()
        Me.txtModel = New System.Windows.Forms.TextBox()
        Me.txtPrice = New System.Windows.Forms.TextBox()
        Me.btnAccept = New System.Windows.Forms.Button()
        Me.cbxCars = New System.Windows.Forms.ListView()
        Me.colNew = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colID = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colMake = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colModel = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colYear = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colPrice = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.chkNewCar = New System.Windows.Forms.CheckBox()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.lblErrors = New System.Windows.Forms.Label()
        Me.lblMake = New System.Windows.Forms.Label()
        Me.lblModel = New System.Windows.Forms.Label()
        Me.LblYear = New System.Windows.Forms.Label()
        Me.lblPrice = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'cmbMake
        '
        Me.cmbMake.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbMake.FormattingEnabled = True
        Me.cmbMake.Items.AddRange(New Object() {"Ford", "Ferrari", "Audi", "Mercdes", "Citron", "Nissan", "Toyota"})
        Me.cmbMake.Location = New System.Drawing.Point(147, 42)
        Me.cmbMake.Name = "cmbMake"
        Me.cmbMake.Size = New System.Drawing.Size(121, 24)
        Me.cmbMake.TabIndex = 0
        '
        'cmbYear
        '
        Me.cmbYear.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbYear.FormattingEnabled = True
        Me.cmbYear.Items.AddRange(New Object() {"1998", "1999", "2000", "2001", "2002", "2003", "2004", "2005", "2006", "2007", "2008", "2009", "2010", "2011", "2012", "2013", "2014", "2015", "2016", "2017", "2018", "2019", "2020"})
        Me.cmbYear.Location = New System.Drawing.Point(147, 100)
        Me.cmbYear.Name = "cmbYear"
        Me.cmbYear.Size = New System.Drawing.Size(121, 24)
        Me.cmbYear.TabIndex = 2
        '
        'txtModel
        '
        Me.txtModel.Location = New System.Drawing.Point(147, 70)
        Me.txtModel.Name = "txtModel"
        Me.txtModel.Size = New System.Drawing.Size(121, 22)
        Me.txtModel.TabIndex = 1
        '
        'txtPrice
        '
        Me.txtPrice.Location = New System.Drawing.Point(147, 130)
        Me.txtPrice.Name = "txtPrice"
        Me.txtPrice.Size = New System.Drawing.Size(121, 22)
        Me.txtPrice.TabIndex = 3
        '
        'btnAccept
        '
        Me.btnAccept.Location = New System.Drawing.Point(130, 471)
        Me.btnAccept.Name = "btnAccept"
        Me.btnAccept.Size = New System.Drawing.Size(75, 23)
        Me.btnAccept.TabIndex = 5
        Me.btnAccept.Text = "Enter"
        Me.btnAccept.UseVisualStyleBackColor = True
        '
        'cbxCars
        '
        Me.cbxCars.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.cbxCars.CheckBoxes = True
        Me.cbxCars.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.colNew, Me.colID, Me.colMake, Me.colModel, Me.colYear, Me.colPrice})
        Me.cbxCars.FullRowSelect = True
        Me.cbxCars.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable
        Me.cbxCars.HideSelection = False
        Me.cbxCars.Location = New System.Drawing.Point(92, 183)
        Me.cbxCars.MultiSelect = False
        Me.cbxCars.Name = "cbxCars"
        Me.cbxCars.Size = New System.Drawing.Size(524, 161)
        Me.cbxCars.TabIndex = 11
        Me.cbxCars.UseCompatibleStateImageBehavior = False
        Me.cbxCars.View = System.Windows.Forms.View.Details
        '
        'colNew
        '
        Me.colNew.Text = "New"
        Me.colNew.Width = 55
        '
        'colID
        '
        Me.colID.Text = "ID"
        Me.colID.Width = 57
        '
        'colMake
        '
        Me.colMake.Text = "Make"
        Me.colMake.Width = 115
        '
        'colModel
        '
        Me.colModel.Text = "Model"
        Me.colModel.Width = 100
        '
        'colYear
        '
        Me.colYear.Text = "Year"
        Me.colYear.Width = 69
        '
        'colPrice
        '
        Me.colPrice.Text = "Price"
        Me.colPrice.Width = 109
        '
        'chkNewCar
        '
        Me.chkNewCar.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.chkNewCar.AutoSize = True
        Me.chkNewCar.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chkNewCar.Location = New System.Drawing.Point(227, 156)
        Me.chkNewCar.Name = "chkNewCar"
        Me.chkNewCar.Size = New System.Drawing.Size(61, 21)
        Me.chkNewCar.TabIndex = 4
        Me.chkNewCar.Text = "&New:"
        Me.chkNewCar.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chkNewCar.UseVisualStyleBackColor = True
        '
        'btnReset
        '
        Me.btnReset.Location = New System.Drawing.Point(280, 471)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(115, 23)
        Me.btnReset.TabIndex = 6
        Me.btnReset.Text = "Reset Page"
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnExit.Location = New System.Drawing.Point(475, 471)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 7
        Me.btnExit.Text = "Exit Page"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'lblErrors
        '
        Me.lblErrors.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblErrors.Location = New System.Drawing.Point(165, 356)
        Me.lblErrors.Name = "lblErrors"
        Me.lblErrors.Size = New System.Drawing.Size(349, 93)
        Me.lblErrors.TabIndex = 15
        '
        'lblMake
        '
        Me.lblMake.AutoSize = True
        Me.lblMake.Location = New System.Drawing.Point(77, 45)
        Me.lblMake.Name = "lblMake"
        Me.lblMake.Size = New System.Drawing.Size(42, 17)
        Me.lblMake.TabIndex = 16
        Me.lblMake.Text = "Make"
        '
        'lblModel
        '
        Me.lblModel.AutoSize = True
        Me.lblModel.Location = New System.Drawing.Point(77, 75)
        Me.lblModel.Name = "lblModel"
        Me.lblModel.Size = New System.Drawing.Size(46, 17)
        Me.lblModel.TabIndex = 17
        Me.lblModel.Text = "Model"
        '
        'LblYear
        '
        Me.LblYear.AutoSize = True
        Me.LblYear.Location = New System.Drawing.Point(77, 103)
        Me.LblYear.Name = "LblYear"
        Me.LblYear.Size = New System.Drawing.Size(38, 17)
        Me.LblYear.TabIndex = 18
        Me.LblYear.Text = "Year"
        '
        'lblPrice
        '
        Me.lblPrice.AutoSize = True
        Me.lblPrice.Location = New System.Drawing.Point(77, 135)
        Me.lblPrice.Name = "lblPrice"
        Me.lblPrice.Size = New System.Drawing.Size(40, 17)
        Me.lblPrice.TabIndex = 19
        Me.lblPrice.Text = "Price"
        '
        'Form1
        '
        Me.AcceptButton = Me.btnAccept
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.btnExit
        Me.ClientSize = New System.Drawing.Size(772, 647)
        Me.Controls.Add(Me.lblPrice)
        Me.Controls.Add(Me.LblYear)
        Me.Controls.Add(Me.lblModel)
        Me.Controls.Add(Me.lblMake)
        Me.Controls.Add(Me.lblErrors)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnReset)
        Me.Controls.Add(Me.chkNewCar)
        Me.Controls.Add(Me.cbxCars)
        Me.Controls.Add(Me.btnAccept)
        Me.Controls.Add(Me.txtPrice)
        Me.Controls.Add(Me.txtModel)
        Me.Controls.Add(Me.cmbYear)
        Me.Controls.Add(Me.cmbMake)
        Me.MinimizeBox = False
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Car Inventory"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents cmbMake As ComboBox
    Friend WithEvents cmbYear As ComboBox
    Friend WithEvents txtModel As TextBox
    Friend WithEvents txtPrice As TextBox
    Friend WithEvents btnAccept As Button
    Friend WithEvents cbxCars As ListView
    Friend WithEvents colNew As ColumnHeader
    Friend WithEvents colID As ColumnHeader
    Friend WithEvents colMake As ColumnHeader
    Friend WithEvents colModel As ColumnHeader
    Friend WithEvents colYear As ColumnHeader
    Friend WithEvents colPrice As ColumnHeader
    Friend WithEvents chkNewCar As CheckBox
    Friend WithEvents btnReset As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents lblErrors As Label
    Friend WithEvents lblMake As Label
    Friend WithEvents lblModel As Label
    Friend WithEvents LblYear As Label
    Friend WithEvents lblPrice As Label
End Class
